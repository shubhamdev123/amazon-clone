# react-amazon-clone

## 👉[ Demo Link ](https://clone-1c520.web.app)


## Run the app locally 

> - npm install

> - npm start



## How to Host a React Application on Firebase

> - firebase login

> - firebase init

Now, choose the project that you have created in firebase

Deploy the application locally

> - npm build

Its all set to deploy to firebase

> - firebase deploy

Hola its done... Deployed to Firebase !!!




